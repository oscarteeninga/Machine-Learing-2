# active-learning-lime
## environment setup - poetry based
### install poetry
https://python-poetry.org/docs/#installation
### prepare virtualenv
```bash
cd active-learning-lime
poetry install
poetry run jupyter-notebook lime-tutorial.ipynb
```